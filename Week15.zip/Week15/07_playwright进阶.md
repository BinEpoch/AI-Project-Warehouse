# 模仿人行为

通过命令行，假设打开浏览器，并访问百度，输入机器学习，并翻页。

```commandline
playwright codegen
```

```commandline
import re
from playwright.sync_api import Playwright, sync_playwright, expect


def run(playwright: Playwright) -> None:
    browser = playwright.chromium.launch(headless=False)
    context = browser.new_context()
    page = context.new_page()
    page.goto("https://www.baidu.com/")
    page.locator("#chat-textarea").click()
    page.get_by_role("textbox").fill("机器学习")
    page.get_by_role("button", name="百度一下").click()
    page.get_by_role("link", name="2", exact=True).click()
    page.get_by_role("link", name="3", exact=True).click()

    context.close()
    browser.close()


with sync_playwright() as playwright:
    run(playwright)
```

