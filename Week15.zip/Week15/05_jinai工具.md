Jina AI 是一家专注于搜索 AI 的领先公司，致力于通过人工智能和深度学习技术，为开发者和企业提供构建强大的搜索应用程序所需的底层模型和工具。 

# 商业API

https://jina.ai/

|              工具类型 |                                         工具地址 |                                 工具说明 | 工具延迟       |
| --------------------: | -----------------------------------------------: | ---------------------------------------: | -------------- |
|            读取器 API |                              `https://r.jina.ai` |              将 URL 转换为大模型友好文本 | 7.9s           |
|            读取器 API |                              `https://s.jina.ai` |     搜索网络并将结果转换为大模型友好文本 | 2.5s           |
|              深度搜索 | `https://deepsearch.jina.ai/v1/chat/completions` |           推理、搜索和迭代以找到最佳答案 | 56.7s          |
|           向量模型API |              `https://api.jina.ai/v1/embeddings` |                  将文本/图片转为定长向量 | 取决于输入大小 |
|            重排器 API |                  `https://api.jina.ai/v1/rerank` |                     按查询对文档进行精排 | 取决于输入大小 |
|            分类器 API |                   `https://api.jina.ai/v1/train` |                   使用训练样本训练分类器 | 取决于输入大小 |
|   分类器 API (零样本) |                `https://api.jina.ai/v1/classify` |             使用零样本分类对输入进行分类 | 取决于输入大小 |
| 分类器 API (少量样本) |                `https://api.jina.ai/v1/classify` | 使用经过训练的少样本分类器对输入进行分类 | 取决于输入大小 |
|            切分器 API |                 `https://api.jina.ai/v1/segment` |                     对长文本进行分词分句 | 0.3s           |


# 开源模型

- https://huggingface.co/jinaai/jina-code-embeddings-1.5b
- https://huggingface.co/jinaai/jina-embeddings-v4
- https://huggingface.co/jinaai/jina-clip-v2
- https://huggingface.co/jinaai/jina-reranker-v3
- https://huggingface.co/jinaai/jina-vlm
- https://huggingface.co/jinaai/ReaderLM-v2

