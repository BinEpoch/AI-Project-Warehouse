DeepSeek-OCR 是由 DeepSeek（深度求索）公司发布的一项创新性的 OCR 技术系统，其设计目标是解决传统大型语言模型（LLM）在处理超长篇幅文档图像时的长上下文瓶颈问题。
- 传统 LLM 在处理长文档时，需要将所有文本转换为大量的文本 Token，很快就会达到模型的上下文窗口限制。
- DeepSeek-OCR 使用**视觉 Token** 作为核心载体，以**极少的 Token** 就能处理和理解超长篇幅的文档图像。

# 模型信息

https://github.com/deepseek-ai/DeepSeek-OCR

# 使用方法

https://docs.vllm.ai/projects/recipes/en/latest/DeepSeek/DeepSeek-OCR.html

vllm部署DeepSeek-OCR
```commandline
vllm serve deepseek-ai/DeepSeek-OCR --logits_processors vllm.model_executor.models.deepseek_ocr:NGramPerReqLogitsProcessor --no-enable-prefix-caching --mm-processor-cache-gb 0
```

代码调用：
```python
import time
from openai import OpenAI

client = OpenAI(
    api_key="EMPTY",
    base_url="http://localhost:8000/v1",
    timeout=3600
)

messages = [
    {
        "role": "user",
        "content": [
            {
                "type": "image_url",
                "image_url": {
                    "url": "https://ofasys-multimodal-wlcb-3-toshanghai.oss-accelerate.aliyuncs.com/wpf272043/keepme/image/receipt.png"
                }
            },
            {
                "type": "text",
                "text": "Free OCR."
            }
        ]
    }
]

start = time.time()
response = client.chat.completions.create(
    model="deepseek-ai/DeepSeek-OCR",
    messages=messages,
    max_tokens=2048,
    temperature=0.0,
    extra_body={
        "skip_special_tokens": False,
        "vllm_xargs": {
            "ngram_size": 30,
            "window_size": 90,
            "whitelist_token_ids": [128821, 128822],
        },
    },
)
print(f"Response costs: {time.time() - start:.2f}s")
print(f"Generated text: {response.choices[0].message.content}")
```