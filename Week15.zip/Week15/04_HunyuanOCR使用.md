**HunyuanOCR** 是由 **腾讯混元视觉团队 (Tencent Hunyuan Vision Team)** 发布的，一款**商业级、开源且轻量级**的 **视觉-语言模型 (VLM)**，专为 OCR (光学字符识别) 任务设计。
- **轻量级架构，卓越性能：** 模型参数仅为 **10 亿 (1B)**，但性能表现优异，超越了许多商业 API、传统 OCR 流程以及参数量更大的模型（如 Qwen3-VL-4B）。
- **端到端 (End-to-End) 范式：** 采用纯端到端架构，**消除了对预处理模块（如版面分析）的依赖**，从根本上解决了传统流水线中常见的**错误累积 (Error Propagation)** 问题，并简化了系统部署。
- **统一多任务能力：** 在一个轻量级框架内，统一支持 **Spotting（文本定位与识别）、Parsing（文档解析）、IE（信息抽取）、VQA（视觉问答）和 Translation（图像翻译）** 等核心 OCR 能力，克服了“OCR 专家模型”能力单一和“通用 VLM”效率低下的局限。

# 模型信息

https://github.com/Tencent-Hunyuan/HunyuanOCR

# 使用方法


https://docs.vllm.ai/projects/recipes/en/latest/DeepSeek/DeepSeek-OCR.html

vllm部署
```commandline
vllm serve tencent/HunyuanOCR --no-enable-prefix-caching --mm-processor-cache-gb 0
```

代码调用：
```python
from openai import OpenAI

client = OpenAI(
    api_key="EMPTY",
    base_url="http://localhost:8000/v1",
    timeout=3600
)

messages = [
    {"role": "system", "content": ""},
    {
        "role": "user",
        "content": [
            {
                "type": "image_url",
                "image_url": {
                    "url": "https://ofasys-multimodal-wlcb-3-toshanghai.oss-accelerate.aliyuncs.com/wpf272043/keepme/image/receipt.png"
                }
            },
            {
                "type": "text",
                "text": (
                    "Extract all information from the main body of the document image "
                    "and represent it in markdown format, ignoring headers and footers."
                    "Tables should be expressed in HTML format, formulas in the document "
                    "should be represented using LaTeX format, and the parsing should be "
                    "organized according to the reading order."
                )
            }
        ]
    }
]

response = client.chat.completions.create(
    model="tencent/HunyuanOCR",
    messages=messages,
    temperature=0.0,
    extra_body={
        "top_k": 1,
        "repetition_penalty": 1.0
    },
)
print(f"Generated text: {response.choices[0].message.content}")
```