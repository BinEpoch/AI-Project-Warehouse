import asyncio
import os
os.environ["OPENAI_API_KEY"] = "sk-7e12cf8185f043bca47c89a17d68b29f"
os.environ["OPENAI_BASE_URL"] = "https://dashscope.aliyuncs.com/compatible-mode/v1"

from agents import Agent, function_tool, AsyncOpenAI, OpenAIChatCompletionsModel, ModelSettings, Runner, ItemHelpers
from agents import set_default_openai_api, set_tracing_disabled
set_default_openai_api("chat_completions")
set_tracing_disabled(True)

import requests
import urllib.parse

@function_tool
def search_jina(query: str) -> str:
    """通过jina进行谷歌搜索"""
    try:
        query = urllib.parse.quote(query) # url encode
        url = f"https://s.jina.ai/?q={query}&hl=zh-cn" # jinai 付费服务
        headers = {
            "Accept": "application/json",
            "Authorization": "Bearer jina_8918effb420d4bff8530c9d9f3bbe536NWhiCZdKQFNgoFLd4aganV1XnsaA",
            "X-Respond-With": "no-content"
        }
        response = requests.get(url, headers=headers, timeout=10) # 调用外部接口
        return response.text[:100]
    except:
        return ""

async def main(question: str):
    # 【agent】的定义
    external_client = AsyncOpenAI(
        api_key=os.environ["OPENAI_API_KEY"],
        base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
    )

    thinking_agent = Agent(
        name="Thinking agent",
        instructions="你是一个擅长对问题进行分解的专家，为了搜索得到全面的答案，请对输入的提问拆分为不同的子问题，并且子问题必须和原始提问相关，子问题要题直接提到主体，每行一个",
        model=OpenAIChatCompletionsModel(
            model="qwen-max",
            openai_client=external_client,
        ),
        model_settings=ModelSettings(parallel_tool_calls=False)
    )

    search_agent = Agent(
        name="Search agent",
        instructions="你是一个搜索引擎，请使用jina进行谷歌搜索，并总结搜索结果",
        tools=[search_jina],
        model=OpenAIChatCompletionsModel(
            model="qwen-max",
            openai_client=external_client,
        ),
        model_settings=ModelSettings(parallel_tool_calls=False)
    )

    summary_agent = Agent(
        name="Summary agent",
        instructions="你是一个总结专家，结合用户的提问，总结搜索结果",
        model=OpenAIChatCompletionsModel(
            model="qwen-max",
            openai_client=external_client,
        ),
        model_settings=ModelSettings(parallel_tool_calls=False)
    )

    # 【agent】执行
    # 对提问拆分为多个子提问
    sub_question = await Runner.run(
        thinking_agent,
        question,
    )
    sub_question = [x for x in sub_question.final_output.split("\n") if len(x) > 2] # 默认提取其中的提问，每行一个提问
    print("分解后的问题:", sub_question)

    # 并行调用，改进为自动对N进行并行，并发运行多个任务（并发运行多个协程（coroutine））
    # openai-agent推荐的并行调用的方式
    res_1, res_2, res_3 = await asyncio.gather(
        Runner.run(
            search_agent,
            sub_question[0],
        ),
        Runner.run(
            search_agent,
            sub_question[1],
        ),
        Runner.run(
            search_agent,
            sub_question[2],
        ),
    )

    outputs = [
        ItemHelpers.text_message_outputs(res_1.new_items),
        ItemHelpers.text_message_outputs(res_2.new_items),
        ItemHelpers.text_message_outputs(res_3.new_items),
    ]
    merge_result = "\n\n".join(outputs)

    # 汇总得到最终的回答
    final_result = await Runner.run(
        summary_agent,
        f"原始提问：{question}\n 搜索结果:{merge_result}",
    )
    print(final_result.final_output)

if __name__ == "__main__":
     asyncio.run(main("分析全运会和的世界杯之间的关系？"))

# 提问：如何学习机器学习？ -》 常见问题，不具备时效性
# 提问：分析全运会和的世界杯之间的关系？-》 非常见问题，具备时效性

# RAG的系统 -》 知识问答（检索知识库、汇总提示词调用大模型） / 闲聊（通用问答，通用提示词调用大模型）
# 例子1: 股票公司智能助手，提问：XX最近的表现，XX行业最近的新闻 -》 时效性，知识库是动态 （推荐互联网当作知识库，搜索引擎替代检索， rerank）
# 例子2: 政府政策问答智能助手， 提问：XX政策的覆盖的范围，xx事情流程 -》 时效性局限在知识库