# 不需要gpu
import asyncio
from playwright.async_api import async_playwright

URL = "https://www.12306.cn/index/"


async def fetch_12306_content():
    print(f"--- 任务开始：打开 {URL} ---")

    # 1. 启动 Playwright 实例
    async with async_playwright() as p:
        # 2. 启动浏览器（这里使用 Chromium, 推荐使用 headless=True 运行）
        browser = await p.chromium.launch(headless=False)

        # 3. 创建新的页面
        page = await browser.new_page()

        try:
            # 4. 导航到指定的 URL
            print("正在导航到 12306 官网...")
            await page.goto(URL, timeout=60000)  # 12306 网站可能加载较慢，设置更长的超时时间 (60秒)

            # 5. 确保页面核心元素加载完成
            # 等待导航栏上的 "首页" 链接出现，这通常意味着页面主体已加载。
            print("正在等待页面核心元素加载...")
            await page.wait_for_selector('text="首页"', timeout=30000)

            # 6. 获取页面的完整 HTML 内容
            print("页面加载完成，正在获取完整 HTML 内容...")
            full_html_content = await page.content()

            # 7. 打印内容摘要
            content_length = len(full_html_content)
            print("-" * 50)
            print(f"✅ 成功获取页面内容，总字节数: {content_length}")
            print("\n--- 内容前 500 个字符摘要 ---")

            # 打印前500个字符以作展示
            print(full_html_content[:500] + "...")
            print("...")
            print("-" * 50)

        except Exception as e:
            print(f"❌ 操作失败或超时: {e}")

        # 8. 关闭浏览器
        await browser.close()
        print("--- 浏览器已关闭，任务结束 ---")


# 运行异步主函数
if __name__ == "__main__":
    asyncio.run(fetch_12306_content())