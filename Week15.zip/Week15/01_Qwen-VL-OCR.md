https://bailian.console.aliyun.com/?tab=api#/api/?type=model&url=2996283

qwen-vl 通用多模态模型 -》 领域微调得到

qwen-vl 支持多轮对话
qwen-vl-ocr 不支持多轮对话，只有单论对话