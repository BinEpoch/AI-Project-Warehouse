PaddleOCR 是由 飞桨 PaddlePaddle 深度学习平台开源的一套 光学字符识别 (OCR) 工具套件，致力于打造丰富、领先、实用的文本识别模型/工具库。
- PaddleOCR 在 中文 场景下表现尤为突出，对中文印刷体、手写体、各种复杂背景的识别精度高。
- PaddleOCR提供了从 文本检测（如 PSENet、DBNet）到 文本识别（如 CRNN、SVTR）以及 文档结构化分析（如 PP-StructureV3）的完整工具链，能够处理表格、版面分析等复杂任务。
- 但PaddleOCR 深度依赖于 PaddlePaddle 深度学习框架，并且进阶使用和微调有一定门槛。

![](https://raw.githubusercontent.com/cuicheng01/PaddleX_doc_images/main/images/paddleocr/README/Arch_cn.jpg)

```commandline
PP-OCRv5 -> 输入图 -> 输出的是文本块位置、文本内容。
PP-StructureV3 -> 输入文档/图 -> 输出的是待格式的文档(latex，markdown)，版面识别/文档解析。   不使用大模型，比如yolo等计算机视觉模型（快）。
PaddleOCR-VL -> 输入图 -> 利用视觉大模型进行文档解析，版面识别/文档解析。     使用多模态大模型，端到端（慢）。
PP-ChatOCRv4 -> 输入文档/图 -> 利用文档解析结果 +  LLM 模型进行问答，信息抽取。
```


# 安装方式 （安装cpu版本即可）

- paddle安装：https://www.paddlepaddle.org.cn/
- paddle-ocr安装：https://github.com/PaddlePaddle/PaddleOCR

# 模块介绍

## PP-OCRv5

通用 OCR 产线用于解决文字识别任务，提取图片中的文字信息以文本形式输出，本产线支持PP-OCRv3、PP-OCRv4、PP-OCRv5模型的使用，其中默认模型为 PaddleOCR3.0 发布的 PP-OCRv5_server 模型，其在多个场景中较 PP-OCRv4_server 提升 13 个百分点。

通用OCR产线中包含以下5个模块。每个模块均可独立进行训练和推理，并包含多个模型。
- [文档图像方向分类模块](https://www.paddleocr.ai/latest/version3.x/module_usage/doc_img_orientation_classification.html) （可选）
- [文本图像矫正模块](https://www.paddleocr.ai/latest/version3.x/module_usage/text_image_unwarping.html) （可选）
- [文本行方向分类模块](https://www.paddleocr.ai/latest/version3.x/module_usage/textline_orientation_classification.html) （可选）
- [文本检测模块](https://www.paddleocr.ai/latest/version3.x/module_usage/text_detection.html)
- [文本识别模块](https://www.paddleocr.ai/latest/version3.x/module_usage/text_recognition.html)

## PP-StructureV3

版面解析通过结合光学字符识别（OCR）、图像处理和机器学习算法，能够识别和提取文档中的文本块、标题、段落、图片、表格以及其他版面元素。此过程通常包括版面分析、元素分析和数据格式化三个主要步骤，最终生成结构化的文档数据，提升数据处理的效率和准确性。


## PP-ChatOCRv4

PP-ChatOCRv4 是飞桨特色的文档和图像智能分析解决方案，结合了 LLM、MLLM 和 OCR 技术，一站式解决版面分析、生僻字、多页 pdf、表格、印章文本识别等常见的复杂文档信息抽取难点问题，结合文心大模型将海量数据和知识相融合，准确率高且应用广泛。

## PaddleOCR-VL

PaddleOCR-VL 是一款先进、高效的文档解析模型，专为文档中的元素识别设计。其核心组件为 PaddleOCR-VL-0.9B，这是一种紧凑而强大的视觉语言模型（VLM），它由 NaViT 风格的动态分辨率视觉编码器与 ERNIE-4.5-0.3B 语言模型组成，能够实现精准的元素识别。

PaddleOCR-VL 在页级级文档解析与元素级识别均达到 SOTA 表现。它显著优于现有的基于Pipeline方案和文档解析多模态方案以及先进的通用多模态大模型，并具备更快的推理速度。这些优势使其非常适合在真实场景中落地部署。


# 使用方式

```
# Run PP-OCRv5 inference
paddleocr ocr -i https://paddle-model-ecology.bj.bcebos.com/paddlex/imgs/demo_image/general_ocr_002.png --use_doc_orientation_classify False --use_doc_unwarping False --use_textline_orientation False  

# Run PP-StructureV3 inference
paddleocr pp_structurev3 -i https://paddle-model-ecology.bj.bcebos.com/paddlex/imgs/demo_image/pp_structure_v3_demo.png --use_doc_orientation_classify False --use_doc_unwarping False

# Get the Qianfan API Key at first, and then run PP-ChatOCRv4 inference
paddleocr pp_chatocrv4_doc -i https://paddle-model-ecology.bj.bcebos.com/paddlex/imgs/demo_image/vehicle_certificate-1.png -k 驾驶室准乘人数 --qianfan_api_key your_api_key --use_doc_orientation_classify False --use_doc_unwarping False 

# Run PaddleOCR-VL inference
paddleocr doc_parser -i https://paddle-model-ecology.bj.bcebos.com/paddlex/imgs/demo_image/paddleocr_vl_demo.png

# Get more information about "paddleocr ocr"
paddleocr ocr --help
```