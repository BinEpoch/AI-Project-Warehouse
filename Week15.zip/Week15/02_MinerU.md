MinerU 是一款由 上海人工智能实验室 开源的，用于 复杂 PDF 文档解析和转换 的工具。它的核心目标是将 PDF 文档高效、准确地转换为易于编辑和阅读的 Markdown 格式。
- 删除页眉、页脚、脚注、页码等元素，确保语义连贯
- 输出符合人类阅读顺序的文本，适用于单栏、多栏及复杂排版
- 保留原文档的结构，包括标题、段落、列表等
- 提取图像、图片描述、表格、表格标题及脚注
- 自动识别并转换文档中的公式为LaTeX格式
- 自动识别并转换文档中的表格为HTML格式
- 自动检测扫描版PDF和乱码PDF，并启用OCR功能
- OCR支持109种语言的检测与识别
- 支持多种输出格式，如多模态与NLP的Markdown、按阅读顺序排序的JSON、含有丰富信息的中间格式等
- 支持多种可视化结果，包括layout可视化、span可视化等，便于高效确认输出效果与质检
- 支持纯CPU环境运行，并支持 GPU(CUDA)/NPU(CANN)/MPS 加速
- 兼容Windows、Linux和Mac平台

> 相比paddlerocr更加体系化，偏向整体的方案，mineru底层使用到了paddlerocr

# 安装方法

- 使用pip或uv安装MinerU （推荐），或 安装包

```
pip install --upgrade pip -i https://mirrors.aliyun.com/pypi/simple
pip install uv -i https://mirrors.aliyun.com/pypi/simple
uv pip install -U "mineru[core]" -i https://mirrors.aliyun.com/pypi/simple 
```

- 通过源码安装MinerU
```
git clone https://github.com/opendatalab/MinerU.git
cd MinerU
uv pip install -e .[core] -i https://mirrors.aliyun.com/pypi/simple
```

- https://github.com/opendatalab/MinerU
- https://opendatalab.github.io/MinerU/usage/quick_usage/

# 使用方法

- 命令行使用 （离线使用）
```commandline
mineru -p <input_path> -o <output_path>
```

- fastapi 部署 （部署为服务，在线使用）
```commandline
mineru-api --host 0.0.0.0 --port 8000
```
