import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Intent Classification Demo",
  description: "Text intent classification with FastAPI + Next.js",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="zh-CN">
      <body className="bg-gray-50 min-h-screen">{children}</body>
    </html>
  );
}
