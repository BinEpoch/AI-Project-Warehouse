"use client";

import { useState } from "react";
import QueryForm from "@/components/QueryForm";
import ResultCard from "@/components/ResultCard";

interface Result {
  label: string;
  confidence: number;
  durationMs: number;
}

export default function Home() {
  const [input, setInput] = useState("");
  const [result, setResult] = useState<Result | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [method, setMethod] = useState<"tfidf" | "llm">("tfidf");

  const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

  async function handleSubmit(text: string) {
    setLoading(true);
    setError(null);
    setResult(null);

    const endpoint =
      method === "llm"
        ? `${API_BASE}/predict-llm`
        : `${API_BASE}/predict`;

    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
      });

      if (!res.ok) {
        throw new Error(`服务器错误 (${res.status})`);
      }

      const data = await res.json();
      setResult({
        label: data.label,
        confidence: data.confidence,
        durationMs: data.duration_ms,
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "未知错误，请检查网络连接");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="max-w-2xl mx-auto px-4 py-16">
      <h1 className="text-3xl font-bold text-gray-800 mb-2">文本意图分类</h1>
      <p className="text-gray-500 mb-8">
        输入一个中文句子，模型将预测其意图类别
      </p>

      <QueryForm
        value={input}
        onChange={setInput}
        onSubmit={handleSubmit}
        disabled={loading}
        method={method}
        onMethodChange={setMethod}
      />

      {loading && (
        <div className="mt-8 p-6 bg-white rounded-xl shadow-md border border-gray-200 text-center text-gray-500">
          正在分类...
        </div>
      )}

      {error && (
        <div className="mt-8 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          {error}
        </div>
      )}

      {result && !loading && !error && (
        <ResultCard
          label={result.label}
          confidence={result.confidence}
          durationMs={result.durationMs}
        />
      )}
    </main>
  );
}
