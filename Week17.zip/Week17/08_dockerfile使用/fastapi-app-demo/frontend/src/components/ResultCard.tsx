"use client";

interface ResultCardProps {
  label: string;
  confidence: number;
  durationMs?: number;
}

function confidenceColor(confidence: number): string {
  if (confidence >= 0.8) return "bg-green-500";
  if (confidence >= 0.5) return "bg-yellow-500";
  return "bg-red-500";
}

export default function ResultCard({
  label,
  confidence,
  durationMs,
}: ResultCardProps) {
  const percentage = (confidence * 100).toFixed(1);

  return (
    <div className="mt-8 p-6 bg-white rounded-xl shadow-md border border-gray-200">
      <h2 className="text-sm text-gray-500 mb-2">预测结果</h2>
      <p className="text-2xl font-bold text-gray-800 mb-4">{label}</p>

      <div className="flex items-center gap-3 mb-3">
        <span className="text-sm text-gray-500">置信度</span>
        <div className="flex-1 h-3 bg-gray-200 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${confidenceColor(confidence)}`}
            style={{ width: `${percentage}%` }}
          />
        </div>
        <span className="text-sm font-semibold text-gray-700 min-w-[4rem] text-right">
          {percentage}%
        </span>
      </div>

      {durationMs !== undefined && (
        <p className="text-xs text-gray-400">耗时：{durationMs}ms</p>
      )}
    </div>
  );
}
