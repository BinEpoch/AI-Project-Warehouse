"use client";

import { FormEvent } from "react";

interface QueryFormProps {
  value: string;
  onChange: (v: string) => void;
  onSubmit: (v: string) => void;
  disabled: boolean;
  method: "tfidf" | "llm";
  onMethodChange: (m: "tfidf" | "llm") => void;
}

export default function QueryForm({
  value,
  onChange,
  onSubmit,
  disabled,
  method,
  onMethodChange,
}: QueryFormProps) {
  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (value.trim() && !disabled) {
      onSubmit(value.trim());
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      <div className="flex gap-3">
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="输入一个中文句子..."
          disabled={disabled}
          className="flex-1 px-4 py-3 border border-gray-300 rounded-lg text-lg
                     focus:outline-none focus:ring-2 focus:ring-blue-400
                     disabled:bg-gray-100 disabled:cursor-not-allowed"
        />
        <button
          type="submit"
          disabled={disabled || !value.trim()}
          className="px-6 py-3 bg-blue-600 text-white font-medium rounded-lg
                     hover:bg-blue-700 disabled:bg-gray-400
                     disabled:cursor-not-allowed transition-colors"
        >
          {disabled ? "分类中..." : "分类"}
        </button>
      </div>
      <div className="flex items-center gap-2 text-sm text-gray-500">
        <span>分类方法：</span>
        {(["tfidf", "llm"] as const).map((m) => (
          <label
            key={m}
            className={`cursor-pointer px-3 py-1 rounded-full border transition-colors ${
              method === m
                ? "border-blue-500 bg-blue-50 text-blue-700"
                : "border-gray-300 hover:border-gray-400"
            }`}
          >
            <input
              type="radio"
              name="method"
              value={m}
              checked={method === m}
              onChange={() => onMethodChange(m)}
              className="sr-only"
            />
            {m === "tfidf" ? "TF-IDF" : "大模型"}
          </label>
        ))}
      </div>
    </form>
  );
}
