from pathlib import Path

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split


def main():
    project_root = Path(__file__).resolve().parent.parent.parent
    dataset_path = project_root / "dataset" / "dataset.csv"
    model_dir = project_root / "backend" / "saved_model"

    print(f"Loading dataset from {dataset_path}")
    df = pd.read_csv(dataset_path, sep="\t", header=None, names=["text", "label"])
    print(f"Loaded {len(df)} samples, {df['label'].nunique()} classes")

    X = df["text"].str.strip()
    y = df["label"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    print(f"Train: {len(X_train)}, Test: {len(X_test)}")

    # Character-level n-grams work well for Chinese without a word segmenter
    vectorizer = TfidfVectorizer(
        analyzer="char_wb", ngram_range=(2, 4), max_features=5000
    )
    X_train_vec = vectorizer.fit_transform(X_train)

    classifier = LogisticRegression(max_iter=1000, multi_class="multinomial")
    classifier.fit(X_train_vec, y_train)

    # Evaluate
    X_test_vec = vectorizer.transform(X_test)
    accuracy = classifier.score(X_test_vec, y_test)
    print(f"Test accuracy: {accuracy:.4f}")

    # Save
    model_dir.mkdir(parents=True, exist_ok=True)
    joblib.dump(vectorizer, model_dir / "vectorizer.pkl")
    joblib.dump(classifier, model_dir / "classifier.pkl")
    print(f"Model saved to {model_dir}")


if __name__ == "__main__":
    main()
