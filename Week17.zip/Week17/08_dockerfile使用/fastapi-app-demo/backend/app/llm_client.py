import json
import time
from pathlib import Path

from openai import OpenAI

# Load config
_config_path = (
    Path(__file__).resolve().parent.parent.parent / "config" / "system_config.json"
)
with open(_config_path) as f:
    _config = json.load(f)

_client = OpenAI(api_key=_config["api_key"], base_url=_config["base_url"])
_model = _config.get("default_model", "qwen3.6-flash")

INTENTS = [
    "FilmTele-Play", "Video-Play", "Music-Play", "Radio-Listen",
    "Alarm-Update", "Weather-Query", "Travel-Query", "HomeAppliance-Control",
    "Calendar-Query", "TVProgram-Play", "Audio-Play", "Other",
]

_SYSTEM_PROMPT = f"""You are an intent classification assistant. Given a Chinese user query, classify it into exactly one of the following intents:

{', '.join(INTENTS)}

Respond in JSON format only, with no extra text:
{{"label": "<intent>", "confidence": <float between 0 and 1>}}

If the query does not clearly match any intent, use "Other". Be concise and accurate."""


def _parse_llm_response(content: str) -> tuple[str, float]:
    """Parse the LLM response into (label, confidence)."""
    cleaned = content.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("\n", 1)[-1]
        cleaned = cleaned.rsplit("\n", 1)[0]
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
    cleaned = cleaned.strip()

    data = json.loads(cleaned)
    label = data["label"]
    confidence = float(data["confidence"])
    return label, confidence


def predict(text: str) -> tuple[str, float, float]:
    """Call the LLM to classify text. Returns (label, confidence, duration_ms)."""
    start = time.perf_counter()
    resp = _client.chat.completions.create(
        model=_model,
        messages=[
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user", "content": text},
        ],
        temperature=0,
        max_tokens=100,
    )
    duration_ms = round((time.perf_counter() - start) * 1000, 1)
    label, confidence = _parse_llm_response(resp.choices[0].message.content)
    return label, confidence, duration_ms
