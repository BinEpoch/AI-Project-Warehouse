from pydantic import BaseModel, Field


class PredictRequest(BaseModel):
    text: str


class PredictResponse(BaseModel):
    text: str
    label: str
    confidence: float
    duration_ms: float = Field(default=0.0, description="Request duration in milliseconds")


class LLMPredictRequest(BaseModel):
    text: str
    model: str | None = Field(default=None, description="Optional LLM model override")
