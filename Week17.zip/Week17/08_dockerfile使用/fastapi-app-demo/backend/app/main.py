import time
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from . import llm_client
from .schemas import LLMPredictRequest, PredictRequest, PredictResponse

app = FastAPI(title="Intent Classification API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Lazy load — model is populated on first request if not already loaded
classifier = None


def _load_or_train():
    global classifier
    if classifier is not None:
        return

    model_dir = Path(__file__).resolve().parent.parent / "saved_model"
    model_path = model_dir / "classifier.pkl"

    if not model_path.exists():
        print("No saved model found. Training now...")
        import sys

        sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
        from training.train import main as train_main

        train_main()

    from .model import IntentClassifier

    classifier = IntentClassifier()
    print(f"Model loaded: {len(classifier.labels)} classes")


@app.on_event("startup")
def startup():
    _load_or_train()


@app.get("/health")
def health():
    _load_or_train()
    return {"status": "ok", "model_classes": len(classifier.labels)}


@app.post("/predict", response_model=PredictResponse)
def predict(req: PredictRequest):
    _load_or_train()
    start = time.perf_counter()
    label, confidence = classifier.predict(req.text)
    duration_ms = round((time.perf_counter() - start) * 1000, 1)
    return PredictResponse(
        text=req.text, label=label, confidence=confidence, duration_ms=duration_ms
    )


@app.post("/predict-llm", response_model=PredictResponse)
def predict_llm(req: LLMPredictRequest):
    label, confidence, duration_ms = llm_client.predict(req.text)
    return PredictResponse(
        text=req.text, label=label, confidence=confidence, duration_ms=duration_ms
    )
