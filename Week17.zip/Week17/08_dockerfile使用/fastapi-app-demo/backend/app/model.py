from pathlib import Path

import joblib


class IntentClassifier:
    def __init__(self):
        model_dir = Path(__file__).resolve().parent.parent / "saved_model"
        self.vectorizer = joblib.load(model_dir / "vectorizer.pkl")
        self.classifier = joblib.load(model_dir / "classifier.pkl")
        self.labels = self.classifier.classes_.tolist()

    def predict(self, text: str) -> tuple[str, float]:
        vec = self.vectorizer.transform([text])
        label = self.classifier.predict(vec)[0]
        probs = self.classifier.predict_proba(vec)[0]
        confidence = float(max(probs))
        return label, confidence
