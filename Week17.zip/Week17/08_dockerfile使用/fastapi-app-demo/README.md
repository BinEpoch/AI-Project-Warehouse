# 文本意图分类 Demo

基于 TF-IDF 与大模型的中文文本意图分类演示项目。

用户输入中文句子，可选择使用 **TF-IDF + LogisticRegression** 或 **大模型 (通义千问)** 进行意图分类，实时查看分类标签、置信度和请求耗时。

## 功能

- **双模式分类**：支持 TF-IDF 传统机器学习与大模型两种分类方式
- **实时反馈**：展示预测标签、置信度（彩色进度条）和请求耗时
- **自动训练**：后端启动时自动检测并训练模型（无需手动操作）
- **12 类意图**：覆盖影视、音乐、天气、闹钟、出行、家电控制等多种场景

## 技术栈

| 组件 | 技术 |
|---|---|
| 后端框架 | FastAPI (Python) |
| 传统模型 | scikit-learn (TfidfVectorizer + LogisticRegression) |
| 大模型 | 通义千问 qwen-flash (DashScope API, OpenAI 兼容接口) |
| 前端框架 | Next.js 14 + TypeScript |
| 样式 | Tailwind CSS |

## 项目结构

```
fastapi-app-demo/
├── dataset/
│   └── dataset.csv              # 12,100 条标注数据，制表符分隔
├── config/
│   └── system_config.json       # 大模型 API 配置
├── backend/
│   ├── requirements.txt         # Python 依赖
│   ├── training/
│   │   └── train.py             # 训练脚本
│   ├── saved_model/             # 序列化模型 (自动生成)
│   │   ├── vectorizer.pkl
│   │   └── classifier.pkl
│   └── app/
│       ├── main.py              # FastAPI 入口 (/predict, /predict-llm, /health)
│       ├── model.py             # TF-IDF 模型封装
│       ├── llm_client.py        # 大模型客户端
│       └── schemas.py           # Pydantic 数据模型
└── frontend/
    ├── package.json
    └── src/
        ├── app/
        │   ├── page.tsx         # 主页面
        │   └── layout.tsx
        └── components/
            ├── QueryForm.tsx    # 输入框 + 方法选择
            └── ResultCard.tsx   # 结果展示卡片
```

## 快速开始

### 1. 环境要求

- Python 3.10+
- Node.js 18+
- npm

### 2. 安装依赖

```bash
# 后端
cd fastapi-app-demo
pip install -r backend/requirements.txt

# 前端
cd frontend && npm install
```

### 3. 配置大模型 API

编辑 `config/system_config.json`：

```json
{
  "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
  "api_key": "your-api-key-here",
  "default_model": "qwen3.6-flash"
}
```

支持任何 OpenAI 兼容的 API（修改 `base_url` 和 `api_key` 即可）。

### 4. 启动服务

```bash
# 终端 1：启动后端 (端口 8000)
uvicorn backend.app.main:app --reload --host 0.0.0.0 --port 8000

# 终端 2：启动前端 (端口 3000)
cd frontend && npm run dev
```

打开浏览器访问 `http://localhost:3000`。

## API 文档

### GET /health

健康检查。返回模型状态与类别数。

```json
// Response 200
{"status": "ok", "model_classes": 12}
```

### POST /predict

使用 TF-IDF 模型进行文本分类。

```json
// Request
{"text": "播放一首周杰伦的歌"}

// Response 200
{"text": "播放一首周杰伦的歌", "label": "Music-Play", "confidence": 0.97, "duration_ms": 4.2}
```

### POST /predict-llm

使用大模型进行文本分类。

```json
// Request
{"text": "播放一首周杰伦的歌"}

// Response 200
{"text": "播放一首周杰伦的歌", "label": "Music-Play", "confidence": 0.99, "duration_ms": 3034.5}
```

## 意图类别

本模型支持 12 类意图：

| 类别 | 说明 | 样本量 |
|---|---|---|
| FilmTele-Play | 影视播放 | 1355 |
| Video-Play | 视频播放 | 1334 |
| Music-Play | 音乐播放 | 1304 |
| Radio-Listen | 收音机收听 | 1285 |
| Alarm-Update | 闹钟设置 | 1264 |
| Weather-Query | 天气查询 | 1229 |
| Travel-Query | 出行查询 | 1220 |
| HomeAppliance-Control | 家电控制 | 1215 |
| Calendar-Query | 日历查询 | 1214 |
| TVProgram-Play | 电视节目播放 | 240 |
| Audio-Play | 音频播放 | 226 |
| Other | 其他 | 214 |

## 模型训练

如需手动重新训练：

```bash
python -m backend.training.train
```

训练使用 char-level n-gram（`char_wb`, 2-4 元），无需中文分词库，测试准确率约 **90%**。

## 镜像打包

```commandline
docker build -t intent-backend -f backend/Dockerfile .

docker build -t intent-frontend -f frontend/Dockerfile .
```

## 镜像运行

```commandline
docker run -p 8000:8000 intent-backend

docker run -p 3000:3000 -e NEXT_PUBLIC_API_URL=http://localhost:8000 intent-frontend &
```

## 注意事项

- 后端 CORS 配置为允许所有来源（`allow_origins=["*"]`），仅限开发环境使用
- 大模型分类需要网络连接和有效的 API Key
- TF-IDF 模型在启动时自动训练（如果 `saved_model/` 为空），无需手动干预
