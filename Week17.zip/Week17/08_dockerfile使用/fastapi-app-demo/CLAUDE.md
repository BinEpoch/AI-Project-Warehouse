# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
# Backend — start the API server
cd fastapi-app-demo && uvicorn backend.app.main:app --reload --host 0.0.0.0 --port 8000

# Backend — train the model manually
cd fastapi-app-demo && python -m backend.training.train

# Frontend — start dev server (port 3000)
cd fastapi-app-demo/frontend && npm run dev

# Frontend — build for production
cd fastapi-app-demo/frontend && npm run build
```

## Project Architecture

A **text intent classification demo** with two services running locally:

### Dataset (`dataset/dataset.csv`)
- 12,100 rows, **tab-separated**, no header
- Columns: `text` (Chinese query), `label` (intent class, 12 categories)
- Run `python -m backend.training.train` to retrain

### Backend (`backend/`)
- **`app/main.py`** — FastAPI application entry point. Three endpoints:
  - `GET /health` — returns `{"status":"ok","model_classes":12}`
  - `POST /predict` — TF-IDF classification, accepts `{"text":"..."}`, returns `{"text","label","confidence","duration_ms"}`
  - `POST /predict-llm` — LLM classification (via DashScope/qwen), same request/response format
  - Auto-trains model on startup if `saved_model/` is empty
  - CORS enabled for `*` (dev mode)
- **`app/model.py`** — `IntentClassifier` class wrapping joblib-loaded vectorizer + classifier
- **`app/llm_client.py`** — LLM classification client using OpenAI-compatible API (reads `config/system_config.json`)
- **`app/schemas.py`** — Pydantic models `PredictRequest`, `LLMPredictRequest`, `PredictResponse` (includes `duration_ms`)
- **`training/train.py`** — Offline training: TfidfVectorizer(char_wb ngrams) + LogisticRegression(multinomial)
  - Uses `analyzer='char_wb', ngram_range=(2,4), max_features=5000` for Chinese text (no segmenter needed)
  - Saves model to `backend/saved_model/vectorizer.pkl` and `classifier.pkl`
  - Test accuracy: ~90%

### Frontend (`frontend/`)
- Next.js 14 + TypeScript + Tailwind CSS, App Router
- **`src/app/page.tsx`** — Client component managing four states: input, loading, error, result
- **`src/components/QueryForm.tsx`** — Text input + submit button + method selector (TF-IDF / LLM radio buttons)
- **`src/components/ResultCard.tsx`** — Shows predicted label + confidence bar (green ≥0.8, yellow ≥0.5, red <0.5) + request duration
- Fetches `http://localhost:8000/predict` or `/predict-llm` depending on selected method

## Key Design Decisions
- Model auto-trains on server start if no serialized model exists
- Chinese text uses char-level n-grams (`char_wb`) — no jieba dependency
- No backend authentication or production CORS restrictions (dev demo only)
