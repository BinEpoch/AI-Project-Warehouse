GGUF 是一种二进制文件格式，专为高效的模型加载、保存和推理而优化。它是 LLM 推理框架 llama.cpp 的开发者 @ggerganov 所开发的，旨在配合 GGML 及其兼容的执行器使用。

- https://huggingface.co/docs/hub/en/gguf#quantization-types
- https://github.com/ggml-org/ggml/blob/master/docs/gguf.md
- https://huggingface.co/collections/unsloth/qwen3

GGUF follow a naming convention of `<BaseName><SizeLabel><FineTune><Version><Encoding><Type><Shard>`.gguf where each component is delimitated by a - if present. Ultimately this is intended to make it easier for humans to at a glance get the most important details of a model. It is not intended to be perfectly parsable in the field due to the diversity of existing gguf filenames.


| 组件 | 描述 | 示例值 |
| :--- | :--- | :--- |
| **BaseName** | 模型基础架构名称（必需） | `Mixtral`, `Hermes-2-Pro-Llama-3` |
| **SizeLabel** | 参数权重等级，如 `<expertCount>x<count><scale-prefix>`（必需） | `8x7B`, `100B` |
| **FineTune** | 模型微调目标（可选） | `instruct`, `chat` |
| **Version** | 模型版本号，格式 `v<Major>.<Minor>`（必需，默认为 `v1.0`） | `v0.1`, `v1.0` |
| **Encoding** | 权重编码/量化方案 | `KQ2`, `F16`, `Q4_0` |
| **Type** | 文件类型（`LoRA`, `vocab`），缺失则为典型张量模型文件 | `LoRA`, `vocab` |
| **Shard** | 分片信息，格式 `<ShardNum>-of-<ShardTotal>`（可选） | `00003-of-00009` |

