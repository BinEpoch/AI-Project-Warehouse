from sentence_transformers import SentenceTransformer

# 上一节课 下载的 模型
# "../models/google-bert/bert-base-chinese/"
model = SentenceTransformer("../models/google-bert/bert-base-chinese/") # 原生bert

sentences = [
    "我今天很开心", # 768 512
    "我今天很不开心",
    "我要去吃海底捞"
]

embeddings = model.encode(sentences) # 正向传播 -》 句子编码 （token的编码 -》 mean pooling）
print(embeddings.shape) # 对称矩阵

similarities = model.similarity(embeddings, embeddings)
print(similarities)

# modelscope download --model BAAI/bge-small-zh-v1.5  --local_dir BAAI/bge-small-zh-v1.5
model = SentenceTransformer("../models/BAAI/bge-small-zh-v1.5/") # sentence-bert 微调之后的
embeddings = model.encode(sentences)
print(embeddings.shape)

similarities = model.similarity(embeddings, embeddings)
print(similarities)
