import openai
import json

client = openai.OpenAI(
    api_key="sk-WkCbMVOViwqUVVdD97E9E88612A14071A40213E24c2989Ab",
    base_url="https://openkey.cloud/v1"
)


response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[{"role": "user", "content":
"""
请帮我进行文本分类，判断下面的文本是正向情感还是负面情感。请直接输出类别，不要有其他输出，可选类别：正/负

我今天很开心。
"""}],
    stream=False, # 非流式 输出，等输出完成了一起返回
    logprobs = True, # 带上每个token的log（概率），chatgpt 支持的
    top_logprobs = 5 # 每个top 5 token
)
print(response) # token 的概率 -》 大模型很自信？幻觉存在？     生成额外的数据集微调其他基础模型



# function call / tools -》 自然语言 转换为 调用什么函数？ 调用函数的参数 -> agent
response = client.chat.completions.create(
    model="gpt-3.5-turbo-0613",
    messages=[
        {"role": "user", "content": "今天是25年9月7日，帮我查询下北京在昨天的天气。"},
    ],
    functions=[
        {
            "name": "get_weather",
            "description": "查询城市在某一天的天气",
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {
                        "type": "string",
                        "description": "城市"
                    },
                    "date_str": {
                        "type": "string",
                        "description": "提起"
                    },
                },
                "required": ["city", "date_str"]
            }
        }
    ]
)

print(response.model_dump_json(indent=4))

def get_weather(city, date_str):
    print(f"{city}  {date_str} 是晴天")


if response.choices[0].message.function_call:
    function_name = response.choices[0].message.function_call.name
    function_args_str = response.choices[0].message.function_call.arguments

    # 将 JSON 字符串解析为 Python 字典
    function_args = json.loads(function_args_str)

    print(f"\n模型请求调用函数: {function_name}")
    print(f"参数: {function_args}\n")

    # --- 推荐的、更安全的方法 ---
    # 使用函数映射来调用本地函数，这比 eval 更安全
    function_map = {
        "get_weather": get_weather
    }

    if function_name in function_map:
        local_function = function_map[function_name]
        result = local_function(**function_args)
        print(result)
